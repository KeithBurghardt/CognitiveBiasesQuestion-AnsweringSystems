<?php
require_once 'db_utility.php';
//require_once 'configure_mysql_start.php';

/*
We configure MySQL to do the following:
	- go to database rank2	
	- create table survey_codes
	- add initial scores to experiments_new
	- when done, users are instructed to go to user_start.php and check/change 2 lines of code
*/


    $conn = db_connect();

    // experiment table
    $exp_tb = "experiments_new";
    //survey code table
    $survey_code_tb = "survey_codes";

    //$strsql = "DELETE FROM $exp_tb";
    //$result = $conn -> query($strsql);
    $strsql = "CREATE TABLE $survey_code_tb (survey_code INT, id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(id))";
    $result = $conn -> query($strsql);
    //$strsql = "DELETE FROM $survey_code_tb";
    //$result = $conn -> query($strsql);
    $random_val = rand(1,10000000);
    $strsql = "INSERT INTO $survey_code_tb (survey_code) VALUES('$random_val')";
    $result = $conn -> query($strsql);

    $colnames = array(	"assignment_id",
		      	"experiment_id",
			"visibility",
			"hit_id",
			"worker_id",
			"ipaddress",
			"NumAns",
			"TimeStarted",
			"AnswerChosen",
			"AnswerOrder",
			"end_time",
			"status",
			"QNum",
			"TimeInArray_2",
			"TimeInArray_8",
			"TimeInArray_10",
			"TimeOutArray_2",
			"TimeOutArray_8",
			"TimeOutArray_10",
			"TimeInArray_0",
			"TimeInArray_1",
			"TimeInArray_3",
			"TimeInArray_4",
			"TimeInArray_5",
			"TimeInArray_6",
			"TimeInArray_7",
			"TimeInArray_9",
			"TimeOutArray_0",
			"TimeOutArray_1",
			"TimeOutArray_3",
			"TimeOutArray_4",
			"TimeOutArray_5",
			"TimeOutArray_6",
			"TimeOutArray_7",
			"TimeOutArray_9",
			"survey_code",
			"Score");

    $colnames_length = count($colnames);
    // update experiments_new such that "NA" -> "Null"
    for($i=1;$i<=$colnames_length;$i ++){
	$colname = $colnames[$i-1];
        $strsql = "ALTER TABLE $exp_tb ALTER '$colname' SET DEFAULT NULL";
        $result = $conn -> query($strsql);
    }
    $NumQs = 10; 
    $TotalNumAs = 8;
    for ($i =1; $i <=$NumQs; $i ++){
        $strsql = "INSERT INTO $exp_tb (QNum,Score,AnswerOrder,AnswerChosen,survey_code) VALUES('$i',-1,1,1,'$random_val')";
    	$result = $conn -> query($strsql);
	for($j = 2; $j <= $TotalNumAs; $j ++){
            $strsql = "INSERT INTO $exp_tb (QNum,Score,AnswerOrder,AnswerChosen,survey_code) VALUES('$i',0,'$j',1,'$random_val')";
            $result = $conn -> query($strsql);
 	}
    }
    if(!$result){
        echo 'no';
        $conn->close();
        exit;
    }  
    
    $conn -> close();
    
    echo 'success';
    exit;

?> 

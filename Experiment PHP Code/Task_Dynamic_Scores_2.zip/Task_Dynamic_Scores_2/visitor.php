
<?php 
require_once 'db_utility.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Ranking Test</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/msg.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="js/visitor.js" type="text/javascript"></script>
</head>


<body class="login">


<div>
	<input type="hidden" id="assignmentId" name="assignmentId" value=""/>
	<input type="hidden" id="workerId" name="workerId" value=""/>
	<input type="hidden" id="hitId" name="hitId" value=""/>
</div>
<?php
//Scores listed next to each answer denote the number of individuals who chose this answer in the past.
?>
<div id="login_form">
		<div class="logo">
		Finding The Best Answer<br>To Questions</div>
		<div class="description">

		In the following pages, please find the most correct answer to each of ten questions on English language usage. 
		We may ask you to explain why you chose each answer at the end of the task. Scores listed next to each answer 
		denote the number of individuals who chose this answer in the past.
		
            <br><br>
		<b>Important information: </b>
			<br>
			<br>
			<ul style="padding-left:40px">
			
			    	<li>You can only perform this job once.</li><br>
				<li>Once you finish the job, a survey code will be shown.</li>
			</ul>
		</div>

    <input type="submit" id="start-btn" class="button" name="commit" value="Start" >

		<span id="msgbox" style="display:none"></span>
	
</div>


</body>
</html>



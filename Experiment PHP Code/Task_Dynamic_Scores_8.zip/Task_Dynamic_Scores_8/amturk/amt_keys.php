<?php
/**
 * Initialize amt\request class
 * @author cpks
 * @license Public Domain
 */
amt\request::init_class('AKIAI5EKH7WFGXOKCZIA', 'xaWdCf7B/Ps4i7NzDFDpio75CYF72qJ0t4Zn4907');

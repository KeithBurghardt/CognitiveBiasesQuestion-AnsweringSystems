<?php 
require_once 'db_utility.php';

if(isset($_POST['CHECK_VISIT_TWICE'])){
	
	$visited_before = true;
	$worker_id = $_POST['CHECK_VISIT_TWICE'];
	$conn = db_connect();

	$strsql= "select * from experiments ".
	         "where worker_id = '$worker_id' and end_time is not null ".
	         "order by end_time desc ".
	         "limit 1 ";
	
	$result = $conn -> query($strsql);
	
	if($result->num_rows == 0){
		$visited_before = false;
	}
	else {
	   /* $row = $result->fetch_assoc();
		$end_t = strtotime($row['end_time']);
		$cur_t = time();
		$gap_t = 60; // 1 minute
		if($end_t + $gap_t < $cur_t);
			$visited_before = false;*/
	}

	if($visited_before)
		echo "VISITED_BEFORE";
	else
		echo "SUCCESS";
	exit;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Ranking Test</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/msg.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="js/visitor.js" type="text/javascript"></script>
</head>

<body class="login">
<div>
	<input type="hidden" id="assignmentId" name="assignmentId" value=""/>
	<input type="hidden" id="workerId" name="workerId" value=""/>
	<input type="hidden" id="hitId" name="hitId" value=""/>
</div>
<div id="login_form">
		<div class="logo">My Stories</div>
		<div class="description">
		    We are conducting a study of the role of social media in promoting science. 
		    Please click 'Start' button and recommend articles from the list below that you think report important scientific topics. 
		    <br><br>
		    When you finish, you will be asked a few questions about the articles you recommended. 
		    <br><br>
		    <b>(Please remember, once you finish the job, system won't allow you to do it again)</b>
		</div>
		<input type="submit" id="start-btn" type="button" class="button" name="commit" value="Start"/>
		<span id="msgbox" style="display:none"></span>	
</div>
</body>
</html>
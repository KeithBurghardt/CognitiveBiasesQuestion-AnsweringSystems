<?php
/**
 * Initialize amt\request class
 * @author cpks
 * @license Public Domain
 */
amt\request::init_class('AKIAJIAXJXVGCDXALMXQ', 'xc6F7h+lfbhgxHhnX9gqnB8+jhRIcAP/Gq7042ME');

<?php

// SELECT COUNT(opr_id), position 
// FROM rank.operations_fixed 
// WHERE click_type='onURL' 
// GROUP BY position;

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('db_utility.php');
require_once ('visibility.php');


$visibility_type = $_GET["visibility"];

$conn = db_connect();
$story_number;

// get total number of stories
$story_table_name = get_story_table_name($visibility_type);
$strsql="SELECT COUNT(*) AS story_num FROM $story_table_name";
$result = $conn->query($strsql);
if (!$result) {
    die('Could not query:' . mysql_error());
}
if($row = $result->fetch_assoc()) {
    $story_number = $row['story_num'];
    $result->close();
}

// get recommendation vs position data for each interface
$opr_table_name = get_operation_table_name($visibility_type);
$strsql="SELECT COUNT(opr_id) AS num, position FROM $opr_table_name WHERE click_type='onURL' GROUP BY position";
$datay = array_fill(0, $story_number, 0);
$datax = array();

for($i=0; $i<$story_number; $i++)
	array_push($datax, $i);

$result = $conn->query($strsql);
if (!$result) {
    die('Could not query:' . mysql_error());
}
while($row = $result->fetch_assoc()){
    $number = $row['num'];
    $position = $row['position'];
    $datay[$position] = $number;
}
$result->close();
$conn->close();

// Setup the graph
$graph = new Graph(1000,250);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("URL click vs position");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($datax);
$graph->xgrid->SetColor('#E3E3E3');

// Create the first line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend($visibility_type);

$graph->legend->SetFrameWeight(1);

// Output line
$graph->Stroke();
?>
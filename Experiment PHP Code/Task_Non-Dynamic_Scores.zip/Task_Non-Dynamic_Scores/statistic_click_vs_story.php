<?php

// SELECT COUNT(opr_id), position 
// FROM rank.operations_fixed 
// WHERE click_type='onButton' 
// GROUP BY position;

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('db_utility.php');
require_once ('visibility.php');


$visibility_type = $_GET["visibility"];

$conn = db_connect();
$datay = array();
$datax = array();

// get total number of stories
$story_table_name = get_story_table_name($visibility_type);
$strsql="SELECT * FROM $story_table_name";
$result = $conn->query($strsql);

if (!$result) {
    die('Could not query:' . mysql_error());
}
$i=0;
while($row = $result->fetch_assoc()){
    $story_id = $row['story_id'];
	$popularity = $row['popularity'];
	$activity = $row['activity'];
	$datay[$i] = $activity - $popularity;
	$datax[$i] = $row['story_id'];
	$i++;
}
$result->close();
$conn->close();

// Setup the graph
$graph = new Graph(1500,250);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("URL clicks vs story");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($datax);
$graph->xgrid->SetColor('#E3E3E3');

// Create the first line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend($visibility_type);

$graph->legend->SetFrameWeight(1);

// Output line
$graph->Stroke();
?>
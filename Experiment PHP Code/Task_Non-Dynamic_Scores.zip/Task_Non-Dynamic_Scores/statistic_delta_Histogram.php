<?php

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_bar.php');
require_once ('db_utility.php');
require_once ('visibility.php');


$visibility_type = 'fixed';

$conn = db_connect();
$datay = array_fill(0, 50, 0);
$datax = array();

$opr_table_name = get_operation_table_name($visibility_type);
$strsql = "SELECT experiment_id, max(position)-min(position) as delta FROM $opr_table_name group by experiment_id";
$result = $conn->query($strsql);

if (!$result) {
    die('Could not query:' . mysql_error());
}

for($i=0; $i<50; $i++){
	array_push($datax, $i);
}

while($row = $result->fetch_assoc()){
	$delta = $row['delta'];
	$datay[$delta]++;
}

$result->close();
$conn->close();

// Create the graph. These two calls are always required
$graph = new Graph(1000,220,'auto');
$graph->SetScale("textlin");

//$theme_class="DefaultTheme";
//$graph->SetTheme(new $theme_class());

// set major and minor tick positions manually
$graph->SetBox(false);

//$graph->ygrid->SetColor('gray');
$graph->ygrid->SetFill(false);
$graph->xaxis->SetTickLabels($datax);
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

// Create the bar plots
$b1plot = new BarPlot($datay);

// ...and add it to the graPH
$graph->Add($b1plot);


$b1plot->SetColor("white");
$b1plot->SetFillGradient("#FF5500","white",GRAD_LEFT_REFLECTION);
$b1plot->SetWidth(15);
$graph->title->Set("delta distribution");

// Display the graph
$graph->Stroke();
?>
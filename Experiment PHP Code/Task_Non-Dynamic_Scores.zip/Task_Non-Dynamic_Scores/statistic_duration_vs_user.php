<?php

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('db_utility.php');
require_once ('visibility.php');


$visibility_type = $_GET["visibility"];

$conn = db_connect();
$datay = array();
$datax = array();

$strsql="SELECT experiment_id,(UNIX_TIMESTAMP(end_time)-UNIX_TIMESTAMP(start_time))/60 as duration FROM experiments where visibility = '$visibility_type' and end_time is not null";

$result = $conn->query($strsql);

if (!$result) {
    die('Could not query:' . mysql_error());
}
$i=0;
$sum = 0;
while($row = $result->fetch_assoc()){
	$datax[$i] = $row['experiment_id'];
	$datay[$i] = $row['duration'];
	$sum = $sum + $row['duration'];
	$i++;
}
$result->close();
$conn->close();
$avg = $sum/$i;

// Setup the graph
$graph = new Graph(7000,250);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("distribution of duration (average: $avg minutes)");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($datax);
$graph->xgrid->SetColor('#E3E3E3');

// Create the first line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend($visibility_type);

$graph->legend->SetFrameWeight(1);

// Output line
$graph->Stroke();
?>
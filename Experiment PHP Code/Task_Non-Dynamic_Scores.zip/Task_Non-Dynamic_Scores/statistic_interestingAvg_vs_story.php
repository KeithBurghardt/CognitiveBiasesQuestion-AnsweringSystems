<?php

// SELECT COUNT(opr_id), position 
// FROM rank.operations_fixed 
// WHERE click_type='onButton' 
// GROUP BY position;

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('db_utility.php');
require_once ('visibility.php');


$conn = db_connect();
$datay = array();
$datax = array();
$assoc = array();

// 1. get recommendation and URLclick for popularity interface
$story_table_name = get_story_table_name("popularity");
$strsql="SELECT * FROM $story_table_name";
$result = $conn->query($strsql);

if (!$result) {
    die('Could not query:' . mysql_error());
}

while($row = $result->fetch_assoc()){
    $story_id = $row['story_id'];
	$popularity = $row['popularity'];
	$activity = $row['activity'];
	$assoc[$story_id] = array($popularity, $activity-$popularity);
}
$result->close();

// 2. get recommendation and URLclick for activity interface
$story_table_name = get_story_table_name("activity");
$strsql="SELECT * FROM $story_table_name";
$result = $conn->query($strsql);

if (!$result) {
	die('Could not query:' . mysql_error());
}

while($row = $result->fetch_assoc()){
	$story_id = $row['story_id'];
	$popularity = $row['popularity'];
	$activity = $row['activity'];
	$assoc[$story_id][0] += $popularity;
	$assoc[$story_id][1] += ($activity-$popularity);
}
$result->close();

// 3. get recommendation and URLclick for fixed interface
$story_table_name = get_story_table_name("fixed");
$strsql="SELECT * FROM $story_table_name";
$result = $conn->query($strsql);

if (!$result) {
	die('Could not query:' . mysql_error());
}

while($row = $result->fetch_assoc()){
	$story_id = $row['story_id'];
	$popularity = $row['popularity'];
	$activity = $row['activity'];
	$assoc[$story_id][0] += $popularity;
	$assoc[$story_id][1] += ($activity-$popularity);
}
$result->close();

// 4. get recommendation and URLclick for random interface
$story_table_name = get_story_table_name("random");
$strsql="SELECT * FROM $story_table_name";
$result = $conn->query($strsql);

if (!$result) {
	die('Could not query:' . mysql_error());
}

while($row = $result->fetch_assoc()){
	$story_id = $row['story_id'];
	$popularity = $row['popularity'];
	$activity = $row['activity'];
	$assoc[$story_id][0] += $popularity;
	$assoc[$story_id][1] += ($activity-$popularity);
}
$result->close();

$conn->close();


foreach ($assoc as $storyId => $pair) {
	if($pair[1]==0)
		array_push($datay, 0);
	else
		array_push($datay, doubleval($pair[0])/doubleval($pair[1])); 
	array_push($datax, $storyId);
}

// Setup the graph
$graph = new Graph(1500,250);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("interesting(avg) vs story");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($datax);
$graph->xgrid->SetColor('#E3E3E3');

// Create the first line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend("");

$graph->legend->SetFrameWeight(1);

// Output line
$graph->Stroke();
?>
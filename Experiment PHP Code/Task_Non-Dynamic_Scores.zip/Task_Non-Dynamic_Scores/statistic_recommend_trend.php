<?php

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('db_utility.php');
require_once ('visibility.php');

function get_datay($visibility_type, $story_id){
	
		$conn = db_connect();
		$expr_number = NULL;
		
		// get total number of experiments
		$opr_table_name = get_operation_table_name($visibility_type);
		$strsql="SELECT COUNT(distinct experiment_id) AS expr_num FROM $opr_table_name";
		$result = $conn->query($strsql);
		if (!$result) {
			die('Could not query:' . mysql_error());
		}
		if($row = $result->fetch_assoc()){
			$expr_number = $row['expr_num'];
			$result->close();
		}
		
		// traverse all the experiments, if user clicks button to recommend the story whose id is storyid
		// we increment the popularity, store in an associative array
		$count = 0;
		$array = array(); // key:experiment_id => value: popularity
		$strsql="SELECT * FROM $opr_table_name";
		$result = $conn->query($strsql);
		if (!$result) {
		    die('Could not query:' . mysql_error());
		}
		while($row = $result->fetch_assoc()){
		    if($row['story_id'] == $story_id && strcmp($row['click_type'], 'onButton') == 0){
		    	$count++;
		    	$array[$row['experiment_id']] = $count;
		    }
			else{
				if(!array_key_exists($row['experiment_id'], $array)){
					$array[$row['experiment_id']] = 0;
				}
			}
		}
		$result->close();
		$conn->close();
		
		// copy data to a new array
		$datay = array();
		$i = 0;
		$previous = 0;
		
		foreach ($array as $key => $value) {
			if($value == 0)
			  $datay[$i] = $previous;
			else{
			  $datay[$i] = $value;
			  $previous = $value;
			}
			$i++;
		}
		return $datay;
}

$visibility = $_GET['visibility'];

// Setup the graph
$graph = new Graph(6000,250);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("recommendation trends ($visibility)");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xgrid->SetColor('#E3E3E3');

// Create the first line
$datay1 = get_datay($visibility, 312);
$p1 = new LinePlot($datay1);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend('312');

// Create the second line
$datay2 = get_datay($visibility, 313);
$p2 = new LinePlot($datay2);
$graph->Add($p2);
$p2->SetColor("#B22222");
$p2->SetLegend('313');

// Create the third line
$datay3 = get_datay($visibility, 314);
$p3 = new LinePlot($datay3);
$graph->Add($p3);
$p3->SetColor("#FF1493");
$p3->SetLegend('314');

// Create the forth line
$datay4 = get_datay($visibility, 315);
$p4 = new LinePlot($datay4);
$graph->Add($p4);
$p4->SetColor("#AA1493");
$p4->SetLegend('315');

// Create the fifth line
$datay5 = get_datay($visibility, 316);
$p5 = new LinePlot($datay5);
$graph->Add($p5);
$p5->SetColor("#DA1493");
$p5->SetLegend('316');

// Create the sixth line
$datay6 = get_datay($visibility, 317);
$p6 = new LinePlot($datay6);
$graph->Add($p6);
$p6->SetColor("#CA1243");
$p6->SetLegend('317');


//$xaxis_length = max(count($datay1), count($datay2), count($datay3), count($datay4));
//$graph->xaxis->SetTickLabels(array_fill(0, $xaxis_length, ''));
$graph->legend->SetFrameWeight(1);

// Output line
$graph->Stroke();
?>
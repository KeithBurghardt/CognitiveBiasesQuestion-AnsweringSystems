<?php // content="text/plain; charset=utf-8"
require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_bar.php');
require_once ('db_utility.php');
require_once ('visibility.php');

// how many unique users looked at each interface (visibility model)
$datay=array();
$labelx=array();

$conn = db_connect();
$all_types = array("popularity", "activity", "fixed", "random");

foreach($all_types as $t){
    $story_table_name = get_story_table_name($t);
    $strsql="SELECT SUM(popularity) AS pop_num FROM $story_table_name";
    array_push($labelx, $t);
    
    $result = $conn->query($strsql);
    if (!$result) {
        die('Could not query:' . mysql_error());
    }
    if($row = $result->fetch_assoc()){
        $number = $row['pop_num'];
        array_push($datay, $number);
        $result->close();
    }
}


// Create the graph. These two calls are always required
$graph = new Graph(1000,220,'auto');
$graph->SetScale("textlin");

//$theme_class="DefaultTheme";
//$graph->SetTheme(new $theme_class());

// set major and minor tick positions manually
$graph->SetBox(false);

//$graph->ygrid->SetColor('gray');
$graph->ygrid->SetFill(false);
$graph->xaxis->SetTickLabels($labelx);
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

// Create the bar plots
$b1plot = new BarPlot($datay);

// ...and add it to the graPH
$graph->Add($b1plot);


$b1plot->SetColor("white");
$b1plot->SetFillGradient("#BB0082","white",GRAD_LEFT_REFLECTION);
$b1plot->SetWidth(45);
$graph->title->Set("recommendation clicks for each interface");

// Display the graph
$graph->Stroke();
?>
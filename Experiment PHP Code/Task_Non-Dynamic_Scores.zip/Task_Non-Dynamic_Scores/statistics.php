<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<title>Statistics</title>
</head>

<body>

        <ul>
    		<li><a href="#totalUser">Total # of Users</a></li>
    		<li><a href="#totalRecommendation">Total # Recommendations</a></li>
    		<li><a href="#totalUrl">Total # of URL clicks</a></li>
    		<li><a href="#recommend_vs_pos"># of recommendations per position</a></li>
    		<li><a href="#click_vs_pos"># of URL clicks per position</a></li>
    		<li><a href="#recommend_vs_story"># of recommendations per story</a></li>
    		<li><a href="#click_vs_story"># of URL clicks per story</a></li>
    		<li><a href="#recommend_trend"># of recommendations (story 312-317) vs time (# of users who completed the task)</a></li>
    		<li><a href="#correlation_recommend">Correlation plots of # of recommendations per story</a></li>
    		<li><a href="#correlation_rank">Correlation plots of # of rank per story</a></li>
    		<li><a href="#recommend_vs_user">Distribution of # of recommendations per user</a></li>
    		<li><a href="#duration_vs_user">Distribution of the amount of time each user spent on the task</a></li>
    		<li><a href="#delta_vs_user">Distribution of the max-min position of the stories user has selected</a></li>
    		<li><a href="#delta_Histogram">Histogram of the distribution of the delta position</a></li>
    		<li><a href="#interesting_vs_story">interesting per story</a></li>
    		<li><a href="#interestingAvg_vs_story">interesting(Avg) per story</a></li>
        </ul>

    	<a name="totalUser"><img class="statistic" src="statistic_user.php"/></a>
    	<a name="totalRecommendation"><img class="statistic" src="statistic_recommends.php"/></a>
    	<a name="totalUrl"><img class="statistic" src="statistic_clicks.php"/></a>

		<a name="recommend_vs_pos">
	    	<img class="statistic" src="statistic_recommend_vs_pos.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_recommend_vs_pos.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_recommend_vs_pos.php?visibility=random"/>
	    	<img class="statistic" src="statistic_recommend_vs_pos.php?visibility=fixed"/>
    	</a>

    	<a name="click_vs_pos">
	    	<img class="statistic" src="statistic_click_vs_pos.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_click_vs_pos.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_click_vs_pos.php?visibility=random"/>
	    	<img class="statistic" src="statistic_click_vs_pos.php?visibility=fixed"/>
    	</a>

    	<a name="recommend_vs_story">
	    	<img class="statistic" src="statistic_recommend_vs_story.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_recommend_vs_story.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_recommend_vs_story.php?visibility=random"/>
	    	<img class="statistic" src="statistic_recommend_vs_story.php?visibility=fixed"/>
    	</a>
    	
    	<a name="click_vs_story">
	    	<img class="statistic" src="statistic_click_vs_story.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_click_vs_story.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_click_vs_story.php?visibility=random"/>
	    	<img class="statistic" src="statistic_click_vs_story.php?visibility=fixed"/>
    	</a>
    	
    	<a name="recommend_trend" >
    		<img class="statistic" src="statistic_recommend_trend.php?visibility=popularity"/>
    		<img class="statistic" src="statistic_recommend_trend.php?visibility=activity"/>
    		<img class="statistic" src="statistic_recommend_trend.php?visibility=random"/>
    		<img class="statistic" src="statistic_recommend_trend.php?visibility=fixed"/>
    	</a>

    	<a name="correlation_recommend">
	    	<img class="statistic" src="statistic_correlation_recommend.php?visibility1=popularity&visibility2=random"/>
	    	<img class="statistic" src="statistic_correlation_recommend.php?visibility1=activity&visibility2=random"/>
	    	<img class="statistic" src="statistic_correlation_recommend.php?visibility1=fixed&visibility2=random"/>
    	</a>
    	
    	<a name="correlation_rank">
	    	<img class="statistic" src="statistic_correlation_rank.php?visibility1=popularity&visibility2=random"/>
	    	<img class="statistic" src="statistic_correlation_rank.php?visibility1=activity&visibility2=random"/>
	    	<img class="statistic" src="statistic_correlation_rank.php?visibility1=fixed&visibility2=random"/>
    	</a>
    	
    	<a name="recommend_vs_user">
	    	<img class="statistic" src="statistic_recommend_vs_user.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_recommend_vs_user.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_recommend_vs_user.php?visibility=random"/>
	    	<img class="statistic" src="statistic_recommend_vs_user.php?visibility=fixed"/>
		</a>
		
		<a name="duration_vs_user">
			<img class="statistic" src="statistic_duration_vs_user.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_duration_vs_user.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_duration_vs_user.php?visibility=random"/>
	    	<img class="statistic" src="statistic_duration_vs_user.php?visibility=fixed"/>
		</a>
		
		<a name="delta_vs_user">
			<img class="statistic" src="statistic_delta_vs_user.php?visibility=popularity"/>
	    	<img class="statistic" src="statistic_delta_vs_user.php?visibility=activity"/>
	    	<img class="statistic" src="statistic_delta_vs_user.php?visibility=random"/>
	    	<img class="statistic" src="statistic_delta_vs_user.php?visibility=fixed"/>
		</a>
		
		<a name="delta_Histogram">
			<img class="statistic" src="statistic_delta_Histogram.php?visibility=popularity"/>
			<img class="statistic" src="statistic_delta_Histogram.php?visibility=activity"/>
			<img class="statistic" src="statistic_delta_Histogram.php?visibility=random"/>
			<img class="statistic" src="statistic_delta_Histogram.php?visibility=fixed"/>
		</a>
		
		<a name="interesting_vs_story">
			<img class="statistic" src="statistic_interesting_vs_story.php?visibility=popularity" />
			<img class="statistic" src="statistic_interesting_vs_story.php?visibility=activity" />
			<img class="statistic" src="statistic_interesting_vs_story.php?visibility=random" />
			<img class="statistic" src="statistic_interesting_vs_story.php?visibility=fixed" />
		</a>
		
		<a name="interestingAvg_vs_story">
			<img class="statistic" src="statistic_interestingAvg_vs_story.php" />
		</a>

</body>
</html>